﻿using BepInEx.Harmony;
using HarmonyLib;
using UnityEngine;

namespace MapMod
{
	internal class Patch
	{
		public static void Hook()
		{
			HarmonyWrapper.PatchAll();
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(ModelValidator), "isValid", MethodType.Getter)]
		private static bool ValidatorPatch(ref bool __result)
		{
			__result = valid;
			return false;
		}

		public static bool valid = true;
	}
}
